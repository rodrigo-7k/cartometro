"""
Gerador de Ícones para CashControl PWA
Execute: pip install pillow && python gerar_icones.py
"""

from PIL import Image, ImageDraw, ImageFont
import os

os.makedirs('static', exist_ok=True)

def criar_icone(tamanho, nome):
    # Fundo azul com gradiente
    img = Image.new('RGBA', (tamanho, tamanho), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Círculo de fundo
    draw.ellipse([4, 4, tamanho-4, tamanho-4], fill=(59, 130, 246))
    
    # Cartão branco
    margem = tamanho // 5
    card_top = tamanho // 3
    card_bottom = 2 * tamanho // 3
    
    draw.rounded_rectangle(
        [margem, card_top, tamanho-margem, card_bottom],
        radius=tamanho//5,
        fill=(255, 255, 255)
    )
    
    # Cifrão
    centro_x = tamanho // 2
    centro_y = tamanho // 2
    
    # Desenhar $ manualmente
    draw.rectangle([centro_x-2, centro_y-14, centro_x+2, centro_y+14], fill=(59, 130, 246))
    draw.rectangle([centro_x-10, centro_y-12, centro_x+10, centro_y-8], fill=(59, 130, 246))
    draw.rectangle([centro_x-10, centro_y+8, centro_x+10, centro_y+12], fill=(59, 130, 246))
    
    # Chip do cartão
    chip_x = tamanho//3 + tamanho//20
    chip_y = card_bottom - tamanho//8
    draw.rounded_rectangle(
        [chip_x, chip_y, chip_x + tamanho//8, chip_y + tamanho//20],
        radius=2,
        fill=(200, 200, 200)
    )
    
    img.save(f'static/{nome}')
    print(f"✅ {nome} ({tamanho}x{tamanho}) criado!")

# Gerar ícones
criar_icone(72, 'icon-72.png')
criar_icone(96, 'icon-96.png')
criar_icone(128, 'icon-128.png')
criar_icone(144, 'icon-144.png')
criar_icone(152, 'icon-152.png')
criar_icone(192, 'icon-192.png')
criar_icone(384, 'icon-384.png')
criar_icone(512, 'icon-512.png')

print("\n🎉 Todos os ícones foram gerados em static/")
print("📱 Agora seu app está pronto para PWA!")