"""
CashControl - Controle de Gastos do Cartão de Crédito
"""

from nicegui import ui
from db import inicializar
from config_service import config_service
from auth_service import get_usuario_logado
import hashlib
import os
import json

USUARIOS_ARQ = 'usuarios.json'

usuario_atual = None
container_principal = None


# =========================
# USUÁRIOS
# =========================
def hash_senha(senha):
    """Gera hash SHA-256 da senha"""
    return hashlib.sha256(senha.encode()).hexdigest()


def carregar_usuarios():
    """Carrega usuários do arquivo JSON"""
    if not os.path.exists(USUARIOS_ARQ):
        usuarios = [{
            "id": 1,
            "nome": "Admin",
            "email": "admin",
            "senha": hash_senha("admin"),
            "avatar_emoji": "👤",
            "avatar": "👤"
        }]
        with open(USUARIOS_ARQ, "w", encoding="utf-8") as f:
            json.dump(usuarios, f, indent=2, ensure_ascii=False)
        return usuarios

    with open(USUARIOS_ARQ, "r", encoding="utf-8") as f:
        return json.load(f)


def autenticar(email, senha):
    """Autentica usuário por email e senha"""
    usuarios = carregar_usuarios()
    senha_hash = hash_senha(senha)
    
    for u in usuarios:
        if u.get("email") == email and u.get("senha") == senha_hash:
            return u
    return None


# =========================
# TELA DE LOGIN
# =========================
@ui.page('/')
def login():
    cor        = config_service.get_primary_color()
    cor_escura = config_service.get_primary_dark()

    ui.add_head_html(f"""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&display=swap');

    *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}

    html, body {{
        height: 100%;
        width: 100%;
        overflow: hidden;
        font-family: 'DM Sans', sans-serif;
    }}

    .lp-root {{
        display: flex;
        height: 100vh;
        height: 100dvh;
        width: 100%;
        overflow: hidden;
    }}

    .lp-brand {{
        flex: 1;
        background: linear-gradient(160deg, {cor_escura} 0%, {cor} 60%, {cor}bb 100%);
        display: flex;
        flex-direction: column;
        justify-content: center;
        padding: 64px 56px;
        position: relative;
        overflow: hidden;
        color: #fff;
    }}

    .lp-brand::before {{
        content: '';
        position: absolute;
        width: 360px; height: 360px;
        border-radius: 50%;
        border: 60px solid rgba(255,255,255,0.05);
        top: -100px; right: -100px;
    }}

    .lp-brand::after {{
        content: '';
        position: absolute;
        width: 260px; height: 260px;
        border-radius: 50%;
        border: 40px solid rgba(255,255,255,0.05);
        bottom: -60px; left: -60px;
    }}

    .lp-brand-content {{ position: relative; z-index: 1; max-width: 420px; }}

    .lp-brand-tag {{
        font-size: 11px; font-weight: 600;
        letter-spacing: 0.12em; text-transform: uppercase;
        color: rgba(255,255,255,0.55); margin-bottom: 20px;
    }}

    .lp-brand-content h1 {{
        font-size: 44px; font-weight: 700;
        letter-spacing: -1.5px; line-height: 1.05; margin-bottom: 18px;
    }}

    .lp-brand-desc {{
        font-size: 15px; color: rgba(255,255,255,0.6);
        line-height: 1.65; max-width: 340px;
    }}

    .lp-brand-items {{
        display: flex; flex-direction: column;
        gap: 12px; margin-top: 40px;
    }}

    .lp-brand-item {{
        display: flex; align-items: center; gap: 10px;
        font-size: 13.5px; color: rgba(255,255,255,0.7);
    }}

    .lp-brand-item-dot {{
        width: 5px; height: 5px; border-radius: 50%;
        background: rgba(255,255,255,0.4); flex-shrink: 0;
    }}

    .lp-form-side {{
        width: 460px; height: 100%; flex-shrink: 0;
        display: flex; align-items: center; justify-content: center;
        background: #fff; padding: 48px 40px;
    }}

    .lp-form-box {{
        width: 100%; max-width: 360px; height: 100%;
        display: flex; flex-direction: column; justify-content: center;
    }}

    .lp-wordmark {{
        display: flex; align-items: center; gap: 9px; margin-bottom: 36px;
    }}

    .lp-wordmark-dot {{
        width: 10px; height: 10px; border-radius: 50%; background: {cor};
    }}

    .lp-wordmark-text {{
        font-size: 14px; font-weight: 600; color: #111; letter-spacing: -0.2px;
    }}

    .lp-form-box h2 {{
        font-size: 26px; font-weight: 700; letter-spacing: -0.8px;
        color: #0f0f0f; margin-bottom: 6px; line-height: 1.15;
    }}

    .lp-subtitle {{
        font-size: 14px; color: #9ca3af; margin-bottom: 32px; font-weight: 400;
    }}

    .lp-field-wrap {{ margin-bottom: 14px; }}

    .lp-field-label {{
        font-size: 12px; font-weight: 500; color: #4b5563;
        margin-bottom: 6px; display: block;
    }}

    .lp-field-wrap .q-field--outlined .q-field__control {{
        border-radius: 10px !important; height: 44px !important;
        background: #fafafa !important; font-size: 14px !important;
    }}

    .lp-field-wrap .q-field--outlined.q-field--focused .q-field__control {{
        border-color: {cor} !important;
        box-shadow: 0 0 0 3px {cor}22 !important;
    }}

    .lp-error {{
        font-size: 12.5px; color: #ef4444; background: #fef2f2;
        border-radius: 8px; padding: 9px 12px; margin-top: 10px;
        display: none; border-left: 3px solid #ef4444;
    }}

    .lp-hint {{
        margin-top: 28px; padding-top: 20px; border-top: 1px solid #f3f4f6;
    }}

    .lp-hint-label {{
        font-size: 11px; font-weight: 600; color: #d1d5db;
        text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 8px;
    }}

    .lp-hint-item {{
        font-size: 12.5px; color: #9ca3af; cursor: pointer;
        transition: color 0.15s; padding: 3px 0;
    }}

    .lp-hint-item:hover {{ color: #374151; }}

    @media (max-width: 768px) {{
        body {{ background: #fff; }}
        .lp-root {{ flex-direction: column; height: 100dvh; }}
        .lp-brand {{ display: none; }}
        .lp-form-side {{
            width: 100%; height: 100%; padding: 0;
            align-items: stretch; background: transparent;
        }}
        .lp-form-box {{
            max-width: 100%; width: 100%; height: 100%;
            display: flex; flex-direction: column;
        }}
        .lp-mobile-header {{
            background: linear-gradient(160deg, {cor_escura} 0%, {cor} 100%);
            padding: 56px 28px 52px; color: #fff;
            position: relative; overflow: hidden; flex-shrink: 0;
        }}
        .lp-mobile-header::after {{
            content: ''; position: absolute;
            width: 200px; height: 200px; border-radius: 50%;
            border: 32px solid rgba(255,255,255,0.07);
            top: -50px; right: -50px;
        }}
        .lp-mobile-header-inner {{ position: relative; z-index: 1; }}
        .lp-mobile-chip {{
            display: inline-flex; align-items: center; gap: 6px;
            background: rgba(255,255,255,0.15); backdrop-filter: blur(8px);
            border-radius: 20px; padding: 4px 12px;
            font-size: 11px; font-weight: 500;
            color: rgba(255,255,255,0.9); margin-bottom: 18px;
        }}
        .lp-mobile-chip-dot {{
            width: 6px; height: 6px; border-radius: 50%;
            background: rgba(255,255,255,0.6);
        }}
        .lp-mobile-header h1 {{
            font-size: 30px; font-weight: 700; letter-spacing: -1px;
            line-height: 1.1; margin-bottom: 8px;
        }}
        .lp-mobile-header p {{
            font-size: 13.5px; color: rgba(255,255,255,0.6); line-height: 1.55;
        }}
        .lp-mobile-form-card {{
            flex: 1; background: #fff;
            border-radius: 24px 24px 0 0; margin-top: -22px;
            padding: 32px 24px 48px; position: relative;
            display: flex; flex-direction: column;
            justify-content: flex-start; overflow-y: auto;
        }}
        .lp-wordmark {{ display: none; }}
        .lp-form-box h2 {{ font-size: 21px; margin-bottom: 5px; }}
        .lp-subtitle {{ margin-bottom: 24px; }}
        .lp-hint {{ margin-top: auto; padding-top: 20px; }}
    }}
    </style>
    """)

    def fazer_login():
        email = email_input.value or ''
        senha = senha_input.value or ''

        if not email or not senha:
            error_label.style('display: block')
            error_label.set_text('⚠️ Preencha todos os campos.')
            return

        usuario = autenticar(email, senha)
        if usuario:
            global usuario_atual
            usuario_atual = usuario
            ui.notify(f'✅ Bem-vindo, {usuario["nome"]}!', type='positive', position='top')
            ui.navigate.to('/app')
        else:
            error_label.style('display: block')
            error_label.set_text('❌ E-mail ou senha incorretos.')

    def preencher_admin():
        email_input.value = 'admin'
        senha_input.value = 'admin'

    with ui.element('div').classes('lp-root'):

        with ui.element('div').classes('lp-brand'):
            with ui.element('div').classes('lp-brand-content'):
                ui.label('CashControl').classes('lp-brand-tag')
                ui.label('Seus gastos\nno controle.').style(
                    'font-size:44px;font-weight:700;letter-spacing:-1.5px;'
                    'line-height:1.05;color:#fff;margin-bottom:18px;white-space:pre-line;')
                ui.label(
                    'Acompanhe gastos do cartão, defina limites '
                    'e organize suas finanças com simplicidade.'
                ).classes('lp-brand-desc')
                with ui.element('div').classes('lp-brand-items'):
                    for item in ['Dashboard em tempo real', 'Controle de limites e parcelamentos', 'Relatórios por categoria e período']:
                        with ui.element('div').classes('lp-brand-item'):
                            ui.element('div').classes('lp-brand-item-dot')
                            ui.label(item)

        with ui.element('div').classes('lp-form-side'):
            with ui.element('div').classes('lp-form-box'):
                with ui.element('div').classes('lp-mobile-header'):
                    with ui.element('div').classes('lp-mobile-header-inner'):
                        with ui.element('div').classes('lp-mobile-chip'):
                            ui.element('div').classes('lp-mobile-chip-dot')
                            ui.label('CashControl')
                        ui.label('Seus gastos\nno controle.').style(
                            'font-size:30px;font-weight:700;letter-spacing:-1px;'
                            'line-height:1.1;color:#fff;margin-bottom:8px;white-space:pre-line;')
                        ui.label('Suas finanças na palma da mão.').style(
                            'font-size:13.5px;color:rgba(255,255,255,0.6);')

                with ui.element('div').classes('lp-mobile-form-card'):
                    with ui.element('div').classes('lp-wordmark'):
                        ui.element('div').classes('lp-wordmark-dot')
                        ui.label('CashControl').classes('lp-wordmark-text')

                    ui.label('Entrar na conta').style(
                        'font-size:26px;font-weight:700;letter-spacing:-0.8px;'
                        'color:#0f0f0f;margin-bottom:6px;line-height:1.15;')
                    ui.label('Bem-vindo de volta 👋').classes('lp-subtitle')

                    with ui.element('div').classes('lp-field-wrap'):
                        ui.label('E-mail').classes('lp-field-label')
                        email_input = ui.input(placeholder='admin').props('outlined dense').classes('w-full')

                    with ui.element('div').classes('lp-field-wrap'):
                        ui.label('Senha').classes('lp-field-label')
                        senha_input = ui.input(placeholder='••••••••', password=True, password_toggle_button=True).props('outlined dense').classes('w-full')

                    error_label = ui.label('').classes('lp-error')

                    ui.button('Entrar', on_click=fazer_login).props('no-caps').style(
                        f'width: 100%; height: 46px; border-radius: 11px; '
                        f'background: {cor} !important; color: white !important; '
                        f'border: none; font-size: 14px; font-weight: 600; cursor: pointer; '
                        f'margin-top: 8px; letter-spacing: 0.01em; font-family: "DM Sans", sans-serif;'
                    )

                    with ui.element('div').classes('lp-hint'):
                        ui.label('Acesso rápido').classes('lp-hint-label')
                        ui.label('👤 admin / admin').classes('lp-hint-item').on('click', preencher_admin)


# =========================
# TELA PRINCIPAL
# =========================
@ui.page('/app')
def app():
    global usuario_atual, container_principal
    
    if not usuario_atual:
        usuario_atual = get_usuario_logado()
    
    if not usuario_atual:
        ui.navigate.to('/')
        return

    from telas.lancamentos import tela_lancamentos
    container_principal = ui.element('div').classes('w-full h-screen')
    tela_lancamentos(container_principal)


# =========================
# INICIALIZAÇÃO
# =========================
inicializar()
carregar_usuarios()

ui.run(
    title="CashControl",
    favicon="💰",
    reload=False,
    show=True,
    port=8080,
    storage_secret='cashcontrol-2024-secret'
)